bl_info = {
    "name": "Retopology Tool",
    "author": "GitHub Copilot",
    "version": (3, 1, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Retopology",
    "description": (
        "Production retopology for sculpts: reduces polygon count, "
        "preserves sharp features, detects holes/circles for ring topology, "
        "converts to clean quad topology with correct edge loops"
    ),
    "category": "Mesh",
}

import bpy
import bmesh
import math
import mathutils
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
)
from bpy.types import Operator, Panel, PropertyGroup


# ---------------------------------------------------------------------------
#  Settings
# ---------------------------------------------------------------------------

class RetopologySettings(PropertyGroup):

    # -- Poly reduction -------------------------------------------------------
    reduce_polycount: BoolProperty(
        name="Reduce Poly Count",
        description="Reduce polygon count to target. Essential for sculpts",
        default=True,
    )
    target_faces: IntProperty(
        name="Target Face Count",
        description="Desired face count for the final mesh",
        default=2_000,
        min=100,
        max=2_000_000,
    )

    # -- Feature preservation -------------------------------------------------
    preserve_sharp: BoolProperty(
        name="Preserve Sharp Edges",
        description=(
            "Detect and mark sharp edges before reduction so they are "
            "preserved in the final topology as proper edge loops"
        ),
        default=True,
    )
    sharp_angle: FloatProperty(
        name="Sharp Angle",
        description=(
            "Edges with face angles sharper than this are treated as "
            "feature edges and will be preserved"
        ),
        default=math.radians(30.0),
        min=math.radians(1.0),
        max=math.radians(80.0),
        subtype="ANGLE",
    )
    detect_ridges: BoolProperty(
        name="Detect Ridges & Valleys",
        description=(
            "Detect curvature ridges and valleys on the surface and mark "
            "edges along them so remeshing aligns edge loops to structural "
            "features like spines, creases, and protrusions"
        ),
        default=True,
    )
    ridge_sensitivity: FloatProperty(
        name="Ridge Sensitivity",
        description=(
            "How aggressively to detect ridges. Lower = only major ridges, "
            "higher = finer features. Controls the Laplacian displacement "
            "threshold relative to the mesh"
        ),
        default=0.5,
        min=0.05,
        max=1.0,
        precision=2,
    )
    ridge_smooth_iterations: IntProperty(
        name="Ridge Smooth",
        description=(
            "Smoothing iterations for the reference surface used in ridge "
            "detection. More = ignores small bumps, detects only large ridges"
        ),
        default=10,
        min=2,
        max=50,
    )

    # -- Hole / circle loop detection -----------------------------------------
    detect_holes: BoolProperty(
        name="Detect Holes & Circles",
        description=(
            "Detect circular openings and holes in the mesh and mark "
            "concentric edge loops around them so remeshing creates "
            "clean ring topology following the hole shape"
        ),
        default=True,
    )
    hole_loop_rings: IntProperty(
        name="Loop Rings",
        description=(
            "How many concentric edge loop rings to mark around each hole. "
            "More rings = more of the surrounding area gets ring topology"
        ),
        default=5,
        min=1,
        max=20,
    )
    hole_min_edges: IntProperty(
        name="Min Hole Edges",
        description="Minimum edges in a boundary loop to be treated as a hole (skip tiny gaps)",
        default=6,
        min=3,
        max=100,
    )

    preserve_boundary: BoolProperty(
        name="Preserve Boundary",
        description="Keep boundary/border edges intact during reduction",
        default=True,
    )
    preserve_seams: BoolProperty(
        name="Preserve UV Seams",
        description="Keep UV seam edges during reduction",
        default=True,
    )
    use_symmetry: BoolProperty(
        name="Symmetry",
        description="Use symmetry during remeshing",
        default=False,
    )
    symmetry_axis: EnumProperty(
        name="Symmetry Axis",
        items=[("X", "X", ""), ("Y", "Y", ""), ("Z", "Z", "")],
        default="X",
    )

    # -- Non-manifold repair --------------------------------------------------
    fix_nonmanifold: BoolProperty(
        name="Fix Non-Manifold",
        description="Repair non-manifold geometry before processing",
        default=True,
    )
    merge_distance: FloatProperty(
        name="Merge Distance",
        description="Weld distance for overlapping vertices",
        default=0.0005,
        min=0.0,
        soft_max=0.01,
        precision=5,
    )
    fill_holes: BoolProperty(
        name="Fill Holes",
        description="Fill boundary-edge holes to make mesh watertight",
        default=True,
    )
    max_hole_edges: IntProperty(
        name="Max Hole Edges",
        description="Only fill holes with this many edges or fewer (0 = unlimited)",
        default=64,
        min=0,
        max=512,
    )
    recalc_normals: BoolProperty(
        name="Recalculate Normals",
        description="Make face normals consistent and outward-pointing",
        default=True,
    )

    # -- Adaptive density -----------------------------------------------------
    adaptive_density: BoolProperty(
        name="Adaptive Density",
        description=(
            "Reduce polygon density in flat, low-detail areas while "
            "keeping detail in curved regions. May go below target face count"
        ),
        default=True,
    )
    adaptive_strength: FloatProperty(
        name="Adaptive Strength",
        description=(
            "How aggressively to reduce flat areas. "
            "Lower = subtle, higher = more reduction in flat regions"
        ),
        default=0.5,
        min=0.1,
        max=1.0,
        precision=2,
    )

    # -- Beautify / smooth ---------------------------------------------------
    beautify: BoolProperty(
        name="Smooth & Relax",
        description="Smooth and relax quad topology for cleaner flow",
        default=True,
    )
    beautify_iterations: IntProperty(
        name="Smooth Iterations",
        description="Number of smoothing passes",
        default=4,
        min=1,
        max=30,
    )
    beautify_strength: FloatProperty(
        name="Smooth Strength",
        description="Per-iteration smoothing strength",
        default=0.3,
        min=0.0,
        max=1.0,
        precision=3,
    )
    preserve_volume: BoolProperty(
        name="Preserve Volume",
        description="Blend vertices back toward original positions to reduce drift",
        default=True,
    )
    volume_strength: FloatProperty(
        name="Volume Preserve",
        description="Blend-back strength toward pre-smooth positions",
        default=0.7,
        min=0.0,
        max=1.0,
        precision=3,
    )

    # -- Surface projection ---------------------------------------------------
    project_to_source: BoolProperty(
        name="Project to Source",
        description="Shrinkwrap result back onto the original high-poly surface",
        default=True,
    )
    project_iterations: IntProperty(
        name="Project Iterations",
        description="Shrinkwrap iterations (more = tighter fit)",
        default=3,
        min=1,
        max=10,
    )
    project_smooth: BoolProperty(
        name="Smooth After Project",
        description="Light smooth after projection to reduce faceting",
        default=True,
    )



# ---------------------------------------------------------------------------
#  Helpers: Blender version compatibility
# ---------------------------------------------------------------------------

def _get_crease_layer(bm):
    """
    Get or create the edge crease layer, compatible with both
    Blender 3.x (bm.edges.layers.crease) and Blender 4.0+/5.0
    (bm.edges.layers.float["crease_edge"]).
    """
    # Blender 4.0+ / 5.0: crease is a float attribute
    if hasattr(bm.edges.layers, "crease"):
        return bm.edges.layers.crease.verify()
    # Fallback: generic float layer named "crease_edge"
    layer = bm.edges.layers.float.get("crease_edge")
    if layer is None:
        layer = bm.edges.layers.float.new("crease_edge")
    return layer


# ---------------------------------------------------------------------------
#  Helpers: Topology stats
# ---------------------------------------------------------------------------

def _count_topology(bm):
    tris = quads = ngons = nm_e = 0
    for f in bm.faces:
        n = len(f.verts)
        if n == 3:
            tris += 1
        elif n == 4:
            quads += 1
        elif n > 4:
            ngons += 1
    for e in bm.edges:
        if not e.is_manifold and not e.is_boundary:
            nm_e += 1
    return {"tris": tris, "quads": quads, "ngons": ngons, "nm_edges": nm_e}


def _mesh_stats_str(mesh) -> str:
    """Quick stats string from a Mesh datablock."""
    return f"V:{len(mesh.vertices):,} F:{len(mesh.polygons):,}"


# ---------------------------------------------------------------------------
#  Helpers: Temporary objects for shrinkwrap
# ---------------------------------------------------------------------------

def _snapshot_as_object(obj):
    """Duplicate mesh into a hidden temp object for use as shrinkwrap target."""
    mesh_copy = obj.data.copy()
    tmp = bpy.data.objects.new("_retopo_source_tmp", mesh_copy)
    bpy.context.collection.objects.link(tmp)
    tmp.matrix_world = obj.matrix_world.copy()
    tmp.hide_viewport = True
    tmp.hide_render = True
    return tmp


def _cleanup_temp_object(tmp):
    if tmp is None:
        return
    mesh = tmp.data
    bpy.data.objects.remove(tmp)
    bpy.data.meshes.remove(mesh)


# ---------------------------------------------------------------------------
#  Phase 1: Sharp edge detection and marking
# ---------------------------------------------------------------------------

def _detect_and_mark_sharp_edges(obj, sharp_angle_threshold):
    """
    Walk every edge. If the angle between its two linked faces exceeds
    the threshold, mark it as Sharp AND as a Crease. This tells both the
    Quadriflow to preserve the edge.

    Returns count of edges marked.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.edges.ensure_lookup_table()

    crease_layer = _get_crease_layer(bm)

    marked = 0
    for edge in bm.edges:
        if not edge.is_valid:
            continue

        # Already marked
        if edge.smooth is False:
            marked += 1
            edge[crease_layer] = 1.0
            continue

        # Boundary edges should be preserved
        if edge.is_boundary:
            edge.smooth = False
            edge[crease_layer] = 1.0
            marked += 1
            continue

        # Check face angle
        if len(edge.link_faces) == 2:
            f1, f2 = edge.link_faces
            if f1.is_valid and f2.is_valid:
                dot = max(-1.0, min(1.0, f1.normal.dot(f2.normal)))
                angle = math.acos(dot)
                if angle >= sharp_angle_threshold:
                    edge.smooth = False
                    edge[crease_layer] = 1.0
                    marked += 1

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()
    return marked


def _detect_and_mark_seam_edges(obj):
    """Also mark UV seam edges as sharp so they get preserved."""
    mesh = obj.data
    marked = 0
    for edge in mesh.edges:
        if edge.use_seam and not edge.use_edge_sharp:
            edge.use_edge_sharp = True
            marked += 1
    return marked


# ---------------------------------------------------------------------------
#  Phase 1b: Ridge / curvature detection
# ---------------------------------------------------------------------------

def _compute_smoothed_positions(bm, iterations):
    """
    Compute smoothed vertex positions by iterative Laplacian smoothing.
    Returns dict {vert_index: smoothed_co}.
    Does NOT modify the mesh — just computes where verts would be.
    """
    positions = {v.index: v.co.copy() for v in bm.verts if v.is_valid}

    for _ in range(iterations):
        new_pos = {}
        for v in bm.verts:
            if not v.is_valid or not v.link_edges:
                new_pos[v.index] = positions.get(v.index, v.co.copy())
                continue
            neighbours = [e.other_vert(v) for e in v.link_edges if e.is_valid]
            if not neighbours:
                new_pos[v.index] = positions[v.index]
                continue
            avg = mathutils.Vector((0, 0, 0))
            for n in neighbours:
                avg += positions.get(n.index, n.co.copy())
            avg /= len(neighbours)
            new_pos[v.index] = positions[v.index].lerp(avg, 0.5)
        positions = new_pos

    return positions


def _detect_and_mark_ridges(obj, settings):
    """
    Detect ridges and valleys on the mesh surface using the difference
    between the original vertex positions and a smoothed version.
    Vertices with high displacement sit on ridges/valleys.
    Edges where BOTH vertices are on ridges get marked as sharp
    so that Quadriflow will align edges along them.

    Returns count of ridge edges marked.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    crease_layer = _get_crease_layer(bm)

    # Step 1: Compute smoothed positions
    smoothed = _compute_smoothed_positions(bm, settings.ridge_smooth_iterations)

    # Step 2: Compute displacement (difference from smoothed = curvature)
    displacements = {}
    max_disp = 0.0
    for v in bm.verts:
        if not v.is_valid:
            continue
        sp = smoothed.get(v.index)
        if sp is None:
            continue
        d = (v.co - sp).length
        displacements[v.index] = d
        if d > max_disp:
            max_disp = d

    if max_disp < 1e-8:
        bm.free()
        return 0

    # Step 3: Normalize displacements to [0, 1]
    for vi in displacements:
        displacements[vi] /= max_disp

    # Step 4: Threshold — vertices above threshold are "ridge" vertices
    threshold = 1.0 - settings.ridge_sensitivity * 0.9

    ridge_verts = set()
    for v in bm.verts:
        if not v.is_valid:
            continue
        if displacements.get(v.index, 0.0) >= threshold:
            ridge_verts.add(v)

    # Step 5: Mark edges where both verts are ridge verts
    marked = 0
    for edge in bm.edges:
        if not edge.is_valid:
            continue
        if edge.smooth is False:
            continue
        v0, v1 = edge.verts
        if v0 in ridge_verts and v1 in ridge_verts:
            edge.smooth = False
            edge[crease_layer] = 1.0
            marked += 1

    # Step 6: Also mark single-vert ridge edges if short + connected to ridge
    if marked > 0:
        avg_edge_len = sum(e.calc_length() for e in bm.edges if e.is_valid) / max(1, len(bm.edges))
        for edge in bm.edges:
            if not edge.is_valid or not edge.smooth:
                continue
            v0, v1 = edge.verts
            if (v0 in ridge_verts or v1 in ridge_verts) and edge.calc_length() < avg_edge_len * 0.8:
                ridge_neighbours = 0
                for v in (v0, v1):
                    for e2 in v.link_edges:
                        if e2 is not edge and e2.is_valid and not e2.smooth:
                            ridge_neighbours += 1
                if ridge_neighbours >= 2:
                    edge.smooth = False
                    edge[crease_layer] = 1.0
                    marked += 1

    # Step 7: Connect ridge edge chains — fill gaps
    for _pass in range(3):
        bm.edges.ensure_lookup_table()
        newly_marked = 0
        for edge in bm.edges:
            if not edge.is_valid or not edge.smooth:
                continue
            v0, v1 = edge.verts
            v0_has_ridge = any(
                e.is_valid and not e.smooth
                for e in v0.link_edges if e is not edge
            )
            v1_has_ridge = any(
                e.is_valid and not e.smooth
                for e in v1.link_edges if e is not edge
            )
            if v0_has_ridge and v1_has_ridge:
                edge.smooth = False
                edge[crease_layer] = 1.0
                newly_marked += 1
        marked += newly_marked
        if newly_marked == 0:
            break

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()
    return marked


def _mark_principal_curvature_edges(obj, settings):
    """
    Compute per-vertex principal curvature direction and mark edges
    that align with it — these guide Quadriflow's field alignment.
    Returns count of edges marked.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    crease_layer = _get_crease_layer(bm)

    vert_curv_dir = {}
    for v in bm.verts:
        if not v.is_valid or len(v.link_faces) < 2:
            continue
        normals = [f.normal for f in v.link_faces if f.is_valid]
        if len(normals) < 2:
            continue
        max_diff = 0.0
        max_dir = None
        for i in range(len(normals)):
            for j in range(i + 1, len(normals)):
                diff = (normals[i] - normals[j]).length
                if diff > max_diff:
                    max_diff = diff
                    cross = normals[i].cross(normals[j])
                    if cross.length > 1e-8:
                        max_dir = cross.normalized()
                    else:
                        max_dir = (normals[i] - normals[j])
                        if max_dir.length > 1e-8:
                            max_dir = max_dir.normalized()
        if max_dir is not None and max_diff > 0.1:
            vert_curv_dir[v] = max_dir

    marked = 0
    for edge in bm.edges:
        if not edge.is_valid or not edge.smooth:
            continue
        v0, v1 = edge.verts
        d0 = vert_curv_dir.get(v0)
        d1 = vert_curv_dir.get(v1)
        if d0 is None or d1 is None:
            continue

        edge_dir = (v1.co - v0.co)
        if edge_dir.length < 1e-8:
            continue
        edge_dir = edge_dir.normalized()

        align0 = abs(edge_dir.dot(d0))
        align1 = abs(edge_dir.dot(d1))
        perp0 = 1.0 - align0
        perp1 = 1.0 - align1

        if (align0 > 0.85 and align1 > 0.85) or (perp0 > 0.85 and perp1 > 0.85):
            edge.smooth = False
            edge[crease_layer] = 0.5
            marked += 1

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()
    return marked


# ---------------------------------------------------------------------------
#  Phase 1c: Hole / circle loop detection
# ---------------------------------------------------------------------------

def _find_boundary_loops(bm):
    """
    Find all closed boundary edge loops in the mesh.
    Returns list of lists of BMVerts, each representing a closed loop.
    """
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    boundary_edges = [e for e in bm.edges if e.is_valid and e.is_boundary]
    if not boundary_edges:
        return []

    visited_edges = set()
    loops = []

    for start_edge in boundary_edges:
        if id(start_edge) in visited_edges:
            continue

        loop_verts = []
        loop_edges = []
        current_edge = start_edge
        current_vert = start_edge.verts[0]

        for _ in range(100_000):
            if id(current_edge) in visited_edges and loop_edges:
                # We've closed the loop
                if current_vert == loop_verts[0] or current_edge is start_edge:
                    loops.append(loop_verts)
                break

            visited_edges.add(id(current_edge))
            loop_edges.append(current_edge)
            loop_verts.append(current_vert)

            other_vert = current_edge.other_vert(current_vert)
            next_edge = None
            for e in other_vert.link_edges:
                if e.is_valid and e.is_boundary and id(e) not in visited_edges:
                    next_edge = e
                    break

            if next_edge is None:
                # Check if we looped back to start
                for e in other_vert.link_edges:
                    if e.is_valid and e is start_edge and len(loop_edges) > 2:
                        loops.append(loop_verts)
                        break
                break

            current_vert = other_vert
            current_edge = next_edge

    return loops


def _compute_loop_center_and_normal(bm, loop_verts):
    """Compute center point and average normal of a boundary loop."""
    center = mathutils.Vector((0, 0, 0))
    for v in loop_verts:
        center += v.co
    center /= len(loop_verts)

    # Compute normal from cross products of consecutive edge vectors
    normal = mathutils.Vector((0, 0, 0))
    n = len(loop_verts)
    for i in range(n):
        v0 = loop_verts[i].co - center
        v1 = loop_verts[(i + 1) % n].co - center
        normal += v0.cross(v1)
    if normal.length > 1e-8:
        normal.normalize()

    return center, normal


def _detect_and_mark_hole_loops(obj, settings):
    """
    Detect boundary loops (holes/circles) and mark concentric rings
    of edges around them as sharp. This guides the remesher to create
    clean ring topology that follows the circular opening.

    For each hole:
    1. Find the boundary loop vertices
    2. Compute center and normal of the hole
    3. Walk outward from the boundary, ring by ring
    4. Mark edges in each ring that are roughly concentric to the hole

    Returns count of edges marked.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    crease_layer = _get_crease_layer(bm)

    # Find all boundary loops
    loops = _find_boundary_loops(bm)

    total_marked = 0

    for loop_verts in loops:
        if len(loop_verts) < settings.hole_min_edges:
            continue

        center, normal = _compute_loop_center_and_normal(bm, loop_verts)

        # Mark boundary edges themselves as sharp
        boundary_vert_set = set(id(v) for v in loop_verts)
        for i in range(len(loop_verts)):
            v0 = loop_verts[i]
            v1 = loop_verts[(i + 1) % len(loop_verts)]
            for e in v0.link_edges:
                if e.is_valid and e.other_vert(v0) is v1:
                    if e.smooth:
                        e.smooth = False
                        e[crease_layer] = 1.0
                        total_marked += 1
                    break

        # Walk outward ring by ring from the boundary
        current_ring_verts = set(loop_verts)
        all_visited_verts = set(loop_verts)

        for ring_idx in range(settings.hole_loop_rings):
            # Find next ring of vertices: neighbours of current ring
            # that haven't been visited yet
            next_ring_verts = set()
            for v in current_ring_verts:
                if not v.is_valid:
                    continue
                for e in v.link_edges:
                    if not e.is_valid:
                        continue
                    ov = e.other_vert(v)
                    if ov.is_valid and ov not in all_visited_verts:
                        next_ring_verts.add(ov)

            if not next_ring_verts:
                break

            # Mark edges between current ring and next ring as RADIAL
            # (these are the "spokes" — we want them perpendicular to loops)
            # We DON'T mark these as sharp — they should be free

            # Mark edges WITHIN the next ring as CONCENTRIC (loop edges)
            # These should be sharp to guide ring topology
            ring_marked = 0
            for v in next_ring_verts:
                if not v.is_valid:
                    continue
                for e in v.link_edges:
                    if not e.is_valid or not e.smooth:
                        continue
                    ov = e.other_vert(v)
                    if ov in next_ring_verts:
                        # This edge connects two verts in the same ring = concentric
                        # Verify it's roughly concentric by checking that both verts
                        # are at similar distance from the hole center
                        d_v = (v.co - center).length
                        d_ov = (ov.co - center).length
                        avg_d = (d_v + d_ov) / 2.0
                        if avg_d > 1e-8 and abs(d_v - d_ov) / avg_d < 0.5:
                            # Additional check: edge direction should be roughly
                            # tangential (perpendicular to radial direction)
                            radial = ((v.co + ov.co) / 2.0 - center)
                            if radial.length > 1e-8:
                                radial_n = radial.normalized()
                                edge_dir = (ov.co - v.co)
                                if edge_dir.length > 1e-8:
                                    edge_dir_n = edge_dir.normalized()
                                    # Tangential = low dot product with radial
                                    dot = abs(radial_n.dot(edge_dir_n))
                                    if dot < 0.6:  # Roughly tangential
                                        e.smooth = False
                                        # Softer crease for outer rings
                                        crease_val = max(0.3, 1.0 - ring_idx * 0.15)
                                        e[crease_layer] = crease_val
                                        ring_marked += 1

            total_marked += ring_marked
            all_visited_verts.update(next_ring_verts)
            current_ring_verts = next_ring_verts

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()
    return total_marked


def _detect_circular_topology(obj, settings):
    """
    Detect areas of the mesh that form circular/cylindrical shapes
    even when there's no actual hole (e.g. tubes, eye sockets on a
    closed mesh). Uses curvature analysis to find circular regions.

    Works by finding rings of high-curvature vertices that form
    closed loops on the surface.

    Returns count of edges marked.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    crease_layer = _get_crease_layer(bm)

    # Compute per-vertex Gaussian-like curvature using angle deficit
    # Flat = 2*pi, convex < 2*pi, saddle > 2*pi
    vert_curvature = {}
    for v in bm.verts:
        if not v.is_valid or len(v.link_faces) < 3:
            continue
        angle_sum = 0.0
        for f in v.link_faces:
            if not f.is_valid:
                continue
            # Find the angle at this vertex in this face
            verts = list(f.verts)
            idx = None
            for i, fv in enumerate(verts):
                if fv is v:
                    idx = i
                    break
            if idx is None:
                continue
            n = len(verts)
            prev_v = verts[(idx - 1) % n]
            next_v = verts[(idx + 1) % n]
            d1 = (prev_v.co - v.co)
            d2 = (next_v.co - v.co)
            if d1.length > 1e-8 and d2.length > 1e-8:
                cos_a = max(-1.0, min(1.0, d1.normalized().dot(d2.normalized())))
                angle_sum += math.acos(cos_a)

        # Angle deficit — deviation from flat (2*pi)
        deficit = abs(2.0 * math.pi - angle_sum)
        vert_curvature[v] = deficit

    # Find vertices with consistently high curvature (on a ring)
    if not vert_curvature:
        bm.free()
        return 0

    max_curv = max(vert_curvature.values())
    if max_curv < 1e-6:
        bm.free()
        return 0

    # Mark edges between two high-curvature vertices that form
    # a roughly circular path (both at similar distance from some center)
    curv_threshold = max_curv * 0.3
    high_curv_verts = {v for v, c in vert_curvature.items() if c > curv_threshold}

    marked = 0
    for edge in bm.edges:
        if not edge.is_valid or not edge.smooth:
            continue
        v0, v1 = edge.verts
        if v0 in high_curv_verts and v1 in high_curv_verts:
            # Check that curvature values are similar
            c0 = vert_curvature.get(v0, 0)
            c1 = vert_curvature.get(v1, 0)
            avg = (c0 + c1) / 2.0
            if avg > 1e-8 and abs(c0 - c1) / avg < 0.7:
                edge.smooth = False
                edge[crease_layer] = 0.4
                marked += 1

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()
    return marked


def _clear_sharp_marks(obj):
    """Remove sharp marks we added (restore soft edges)."""
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    crease_layer = _get_crease_layer(bm)
    for edge in bm.edges:
        edge.smooth = True
        edge[crease_layer] = 0.0
    bm.to_mesh(mesh)
    mesh.update()
    bm.free()


# ---------------------------------------------------------------------------
#  Phase 2: Non-manifold repair
# ---------------------------------------------------------------------------

def _repair_nonmanifold(obj, settings):
    """
    Repair non-manifold geometry using BMesh.
    Operates on the mesh in-place.
    Returns info dict.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)

    info = {"merged": 0, "holes_filled": 0, "nm_fixed": 0, "loose_removed": 0}

    # Merge by distance
    vc = len(bm.verts)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=settings.merge_distance)
    info["merged"] = vc - len(bm.verts)

    # Dissolve degenerate
    bmesh.ops.dissolve_degenerate(bm, edges=bm.edges, dist=max(settings.merge_distance, 1e-6))

    # Remove loose geometry
    loose_v = [v for v in bm.verts if v.is_valid and not v.link_edges]
    loose_e = [e for e in bm.edges if e.is_valid and not e.link_faces]
    info["loose_removed"] = len(loose_v) + len(loose_e)
    if loose_e:
        bmesh.ops.delete(bm, geom=loose_e, context="EDGES")
    if loose_v:
        bmesh.ops.delete(bm, geom=loose_v, context="VERTS")
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    # Remove duplicate faces
    sig_map = {}
    dups = []
    for f in bm.faces:
        if not f.is_valid:
            continue
        sig = tuple(sorted(v.index for v in f.verts))
        if sig in sig_map:
            dups.append(f)
        else:
            sig_map[sig] = f
    if dups:
        bmesh.ops.delete(bm, geom=dups, context="FACES")
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

    # Fix non-manifold edges (3+ linked faces)
    nm_fixed = 0
    for _ in range(4):
        bm.edges.ensure_lookup_table()
        nm = [e for e in bm.edges if e.is_valid and not e.is_manifold
              and not e.is_boundary and len(e.link_faces) >= 3]
        if not nm:
            break
        for edge in nm:
            if not edge.is_valid:
                continue
            faces = sorted([f for f in edge.link_faces if f.is_valid],
                           key=lambda f: f.calc_area(), reverse=True)
            if len(faces) <= 2:
                continue
            try:
                bmesh.ops.delete(bm, geom=faces[2:], context="FACES")
                nm_fixed += len(faces) - 2
            except Exception:
                pass
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

    # Clean leftover loose
    for lst, ctx in [
        ([e for e in bm.edges if e.is_valid and not e.link_faces], "EDGES"),
        ([v for v in bm.verts if v.is_valid and not v.link_edges], "VERTS"),
    ]:
        if lst:
            bmesh.ops.delete(bm, geom=lst, context=ctx)

    # Split remaining non-manifold edges
    for _ in range(3):
        bm.edges.ensure_lookup_table()
        nm = [e for e in bm.edges if e.is_valid and not e.is_manifold and not e.is_boundary]
        if not nm:
            break
        try:
            bmesh.ops.split_edges(bm, edges=nm)
            nm_fixed += len(nm)
        except Exception:
            break
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
    info["nm_fixed"] = nm_fixed

    # Fill boundary holes
    if settings.fill_holes:
        info["holes_filled"] = _fill_boundary_holes(bm, settings.max_hole_edges)

    # Remove interior faces (all edges have 3+ faces)
    bm.faces.ensure_lookup_table()
    interior = [f for f in bm.faces if f.is_valid and all(len(e.link_faces) >= 3 for e in f.edges)]
    if interior:
        bmesh.ops.delete(bm, geom=interior, context="FACES")

    # Recalculate normals
    if settings.recalc_normals:
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.normal_update()

    bm.to_mesh(mesh)
    mesh.validate(verbose=False)
    mesh.update()
    bm.free()
    return info


def _fill_boundary_holes(bm, max_edges):
    """Find boundary loops and fill them."""
    filled = 0
    for _ in range(50):
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        boundary = [e for e in bm.edges if e.is_valid and e.is_boundary]
        if not boundary:
            break
        visited = set()
        loops = []
        for se in boundary:
            if id(se) in visited:
                continue
            lv, le = [], []
            ce, cv = se, se.verts[0]
            for _ in range(10_000):
                if id(ce) in visited and le:
                    break
                visited.add(id(ce))
                le.append(ce)
                lv.append(cv)
                ov = ce.other_vert(cv)
                ne = None
                for e in ov.link_edges:
                    if e.is_valid and e.is_boundary and id(e) not in visited:
                        ne = e
                        break
                if ne is None:
                    for e in ov.link_edges:
                        if e.is_valid and e is se and len(le) > 2:
                            loops.append((lv, le))
                            break
                    break
                cv, ce = ov, ne
        if not loops:
            break
        ct = 0
        for lv, le in loops:
            n = len(le)
            if (max_edges > 0 and n > max_edges) or n < 3:
                continue
            try:
                r = bmesh.ops.contextual_create(bm, geom=lv + le)
                if any(f for f in r.get("faces", []) if f.is_valid):
                    ct += 1
            except Exception:
                try:
                    r = bmesh.ops.edgenet_fill(bm, edges=le)
                    if any(f for f in r.get("faces", []) if f.is_valid):
                        ct += 1
                except Exception:
                    pass
        filled += ct
        if ct == 0:
            break
    return filled


# ---------------------------------------------------------------------------
#  Phase 3: Poly reduction
# ---------------------------------------------------------------------------

def _reduce_with_quadriflow(obj, settings):
    """
    Uses Blender's Quadriflow remesher which produces clean all-quad output.
    """
    _reduce_with_quadriflow_target(obj, settings.target_faces, settings)


def _reduce_with_quadriflow_target(obj, target_faces, settings):
    """
    Quadriflow remesh to a specific face count.
    """
    bpy.context.view_layer.objects.active = obj

    target = max(target_faces, 100)

    bpy.ops.object.quadriflow_remesh(
        target_faces=target,
        use_preserve_sharp=settings.preserve_sharp,
        use_preserve_boundary=settings.preserve_boundary,
        use_mesh_symmetry=settings.use_symmetry,
        seed=0,
    )


# ---------------------------------------------------------------------------
#  Phase 4b: Adaptive density — reduce flat regions, preserve detail
# ---------------------------------------------------------------------------

def _quad_quality(f):
    """Quality score for a quad: 1.0 = perfect square, lower = worse."""
    if not f.is_valid or len(f.verts) != 4:
        return 0.0
    verts = [v.co for v in f.verts]
    # Angle deviation from 90 degrees
    angle_err = 0.0
    for i in range(4):
        a = verts[(i - 1) % 4]
        b = verts[i]
        c = verts[(i + 1) % 4]
        d1 = (a - b).normalized()
        d2 = (c - b).normalized()
        dot = max(-1.0, min(1.0, d1.dot(d2)))
        angle = math.acos(dot)
        angle_err += abs(angle - math.pi / 2)
    angle_err /= 4.0
    # Edge length ratio
    lengths = [(verts[i] - verts[(i + 1) % 4]).length for i in range(4)]
    max_l = max(lengths)
    min_l = min(lengths)
    ratio = min_l / max(max_l, 1e-10)
    return max(0.0, 1.0 - angle_err / math.pi) * ratio


def _vertex_curvature(v):
    """Estimate curvature at a vertex from normal deviation of neighbors."""
    if not v.is_valid or not v.link_edges:
        return 0.0
    n = v.normal
    if n.length_squared < 1e-10:
        return 0.0
    max_dev = 0.0
    for e in v.link_edges:
        if not e.is_valid:
            continue
        other = e.other_vert(v)
        if not other.is_valid:
            continue
        dev = 1.0 - max(-1.0, min(1.0, n.dot(other.normal)))
        if dev > max_dev:
            max_dev = dev
    return max_dev


def _opposite_edge_at_vertex(edge, vert):
    """
    At a valence-4 vertex in a quad mesh, find the edge directly opposite
    to 'edge'.  The opposite edge shares NO face with the input edge.
    Returns None if the vertex isn't valence-4 or no opposite exists.
    """
    if not vert.is_valid or len(vert.link_edges) != 4:
        return None
    edge_faces = set(f for f in edge.link_faces if f.is_valid)
    for e in vert.link_edges:
        if e is edge or not e.is_valid:
            continue
        e_faces = set(f for f in e.link_faces if f.is_valid)
        if not (edge_faces & e_faces):
            return e
    return None


def _trace_edge_loop(start_edge):
    """
    Trace a connected edge loop through a quad mesh.
    Follows edges that share vertices, continuing "straight through"
    each valence-4 vertex (via the opposite edge at each vertex).
    Returns a list of connected edges forming the loop.
    """
    loop = [start_edge]
    visited = {start_edge}

    # Trace in both directions from start_edge
    for direction in range(2):
        current_edge = start_edge
        current_vert = start_edge.verts[direction]

        while True:
            next_edge = _opposite_edge_at_vertex(current_edge, current_vert)
            if next_edge is None or next_edge in visited:
                break
            if not next_edge.is_valid or next_edge.is_boundary:
                break

            visited.add(next_edge)
            if direction == 0:
                loop.append(next_edge)
            else:
                loop.insert(0, next_edge)

            # Advance to the other end of next_edge
            current_vert = next_edge.other_vert(current_vert)
            current_edge = next_edge

    return loop


def _reduce_flat_regions(obj, strength=0.5):
    """
    Adaptive density: dissolve entire edge loops in flat areas to cleanly
    reduce face count.  After dissolving a loop, degree-2 interior verts
    are removed so adjacent quads merge cleanly.

    strength: 0.1 (subtle) to 1.0 (aggressive)

    Returns (net_faces_removed, final_tri_count, final_ngon_count).
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()
    bm.normal_update()

    total_faces_before = len(bm.faces)
    if total_faces_before < 50:
        bm.free()
        return 0, 0, 0

    # Target removal: strength 0.1 → 5%, 0.5 → 15%, 1.0 → 30%
    target_removal = int(total_faces_before * (0.05 + strength * 0.25))
    total_removed = 0
    loops_dissolved = 0

    for iteration in range(30):
        if total_removed >= target_removal:
            break

        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        bm.normal_update()

        # --- Find all edge loops ------------------------------------------
        visited_edges = set()
        all_loops = []

        for e in bm.edges:
            if not e.is_valid or e in visited_edges:
                continue
            if e.is_boundary or len(e.link_faces) != 2:
                continue
            if any(len(f.verts) != 4 for f in e.link_faces):
                continue

            loop = _trace_edge_loop(e)
            for le in loop:
                visited_edges.add(le)
            if len(loop) >= 3:
                all_loops.append(loop)

        if not all_loops:
            break

        # --- Score loops: skip sharp, rank by flatness --------------------
        scored = []
        for loop in all_loops:
            # Skip loops containing sharp (non-smooth) or boundary edges
            if any((not le.smooth or le.is_boundary) for le in loop
                   if le.is_valid):
                continue

            curvs = []
            for e in loop:
                if not e.is_valid:
                    continue
                for v in e.verts:
                    if v.is_valid:
                        curvs.append(_vertex_curvature(v))
            if not curvs:
                continue

            avg_curv = sum(curvs) / len(curvs)
            scored.append((avg_curv, loop))

        if not scored:
            break

        scored.sort(key=lambda x: x[0])  # flattest first

        # Curvature gate: higher strength → dissolve more curved loops
        #   strength 0.1 → max 0.15,  strength 0.5 → 0.35,  1.0 → 0.6
        max_curv = 0.1 + strength * 0.5
        best_curv, best_loop = scored[0]
        if best_curv > max_curv:
            break

        # --- Dissolve the loop -------------------------------------------
        valid_edges = [e for e in best_loop if e.is_valid]
        if not valid_edges:
            break

        faces_before = sum(1 for f in bm.faces if f.is_valid)

        try:
            bmesh.ops.dissolve_edges(bm, edges=valid_edges)
        except Exception:
            break

        # Clean up degree-2 interior vertices — this merges the two
        # remaining edges at each former loop vertex into one edge,
        # turning the adjacent n-gons back into clean quads.
        bm.verts.ensure_lookup_table()
        deg2 = [v for v in bm.verts
                if v.is_valid and not v.is_boundary
                and len(v.link_edges) == 2]
        if deg2:
            try:
                bmesh.ops.dissolve_verts(bm, verts=deg2)
            except Exception:
                pass

        bm.faces.ensure_lookup_table()
        faces_after = sum(1 for f in bm.faces if f.is_valid)
        removed = faces_before - faces_after
        total_removed += removed
        loops_dissolved += 1

        print(f"[Adaptive] Loop {loops_dissolved}: {len(valid_edges)} edges, "
              f"curv={best_curv:.4f}, removed {removed} faces")

        if removed == 0:
            # This loop didn't help, stop trying
            break

    # --- Final cleanup: handle any stray tris/ngons -----------------------
    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    ngons = [f for f in bm.faces if f.is_valid and len(f.verts) > 4]
    if ngons:
        bmesh.ops.triangulate(bm, faces=ngons,
                              quad_method="BEAUTY", ngon_method="BEAUTY")
        for join_angle in (60, 120):
            bm.faces.ensure_lookup_table()
            tris = [f for f in bm.faces if f.is_valid and len(f.verts) == 3]
            if len(tris) < 2:
                break
            bmesh.ops.join_triangles(
                bm, faces=tris,
                angle_face_threshold=math.radians(join_angle),
                angle_shape_threshold=math.radians(join_angle),
                topology_influence=1.0,
            )

    # --- Count results ----------------------------------------------------
    bm.faces.ensure_lookup_table()
    total_faces_after = len(bm.faces)
    net_removed = total_faces_before - total_faces_after

    final_tris = sum(1 for f in bm.faces if f.is_valid and len(f.verts) == 3)
    final_ngons = sum(1 for f in bm.faces if f.is_valid and len(f.verts) > 4)

    print(f"[Adaptive] Total: {loops_dissolved} loops dissolved, "
          f"faces {total_faces_before} → {total_faces_after} "
          f"(removed {net_removed}, T:{final_tris} N:{final_ngons})")

    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.normal_update()
    bm.to_mesh(mesh)
    mesh.update()
    bm.free()

    return net_removed, final_tris, final_ngons


# ---------------------------------------------------------------------------
#  Phase 5: Beautify & smooth
# ---------------------------------------------------------------------------

def _beautify_and_smooth(obj, settings):
    """
    Smooth and relax the quad mesh for cleaner edge flow.
    Respects sharp edges — they are not smoothed across.
    Ridge verts are constrained to slide along the ridge direction only,
    so smoothing improves flow without losing feature alignment.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()

    quads = [f for f in bm.faces if f.is_valid and len(f.verts) == 4]
    if not quads:
        bm.free()
        return

    crease_layer = _get_crease_layer(bm)

    boundary_verts = set()
    ridge_verts = {}  # {BMVert: ridge_direction_vector}

    for v in bm.verts:
        if not v.is_valid:
            continue
        sharp_edges = []
        for e in v.link_edges:
            if not e.smooth or e.is_boundary:
                sharp_edges.append(e)

        if len(sharp_edges) >= 3:
            boundary_verts.add(v)
        elif len(sharp_edges) == 2:
            e1, e2 = sharp_edges
            d1 = (e1.other_vert(v).co - v.co)
            d2 = (e2.other_vert(v).co - v.co)
            ridge_dir = (d1.normalized() + d2.normalized())
            if ridge_dir.length > 1e-8:
                ridge_verts[v] = ridge_dir.normalized()
            else:
                ridge_verts[v] = d1.normalized() if d1.length > 1e-8 else None
        elif len(sharp_edges) == 1:
            boundary_verts.add(v)

    smoothable = [v for v in bm.verts if v.is_valid
                  and v not in boundary_verts and v not in ridge_verts]
    ridge_list = [v for v in ridge_verts if v.is_valid]

    orig_pos = {}
    if settings.preserve_volume:
        for v in smoothable:
            orig_pos[v] = v.co.copy()
        for v in ridge_list:
            orig_pos[v] = v.co.copy()

    for _ in range(settings.beautify_iterations):
        if quads:
            bmesh.ops.planar_faces(bm, faces=quads, iterations=1, factor=1.0)

        if smoothable:
            bmesh.ops.smooth_vert(
                bm, verts=smoothable, factor=settings.beautify_strength,
                use_axis_x=True, use_axis_y=True, use_axis_z=True,
            )

        # Smooth ridge verts constrained to ridge direction
        for v in ridge_list:
            if not v.is_valid:
                continue
            rd = ridge_verts.get(v)
            if rd is None:
                continue
            neighbours = [e.other_vert(v) for e in v.link_edges if e.is_valid]
            if not neighbours:
                continue
            avg = mathutils.Vector((0, 0, 0))
            for n in neighbours:
                avg += n.co
            avg /= len(neighbours)
            delta = avg - v.co
            proj = rd * delta.dot(rd)
            v.co += proj * settings.beautify_strength

        if settings.preserve_volume and orig_pos:
            for v, oc in orig_pos.items():
                if v.is_valid:
                    v.co = v.co.lerp(oc, settings.volume_strength)

        quads = [f for f in bm.faces if f.is_valid and len(f.verts) == 4]
        smoothable = [v for v in bm.verts if v.is_valid
                      and v not in boundary_verts and v not in ridge_verts]

    bm.to_mesh(mesh)
    mesh.update()
    bm.free()


# ---------------------------------------------------------------------------
#  Phase 6: Project back onto source
# ---------------------------------------------------------------------------

def _project_to_surface(obj, source_obj, settings):
    """Project result onto the original high-poly surface using BVH raycast
    along vertex normals.  This avoids NEAREST_SURFACEPOINT snapping verts
    across concavities."""
    from mathutils.bvhtree import BVHTree

    mesh = obj.data

    # Build BVH from source mesh via BMesh (works on temp objects)
    src_bm = bmesh.new()
    src_bm.from_mesh(source_obj.data)
    src_bm.transform(source_obj.matrix_world)
    bvh = BVHTree.FromBMesh(src_bm)
    src_bm.free()

    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.transform(obj.matrix_world)
    bm.verts.ensure_lookup_table()
    bm.normal_update()

    for _ in range(settings.project_iterations):
        for v in bm.verts:
            if not v.is_valid:
                continue
            origin = v.co
            direction = v.normal
            if direction.length_squared < 1e-10:
                continue

            # Cast forward and backward along normal
            hit_pos = None
            best_dist = float('inf')

            for sign in (1.0, -1.0):
                loc, normal, idx, dist = bvh.ray_cast(origin, direction * sign)
                if loc is not None and dist < best_dist:
                    best_dist = dist
                    hit_pos = loc

            if hit_pos is not None:
                v.co = hit_pos

    if settings.project_smooth:
        bmesh.ops.smooth_vert(
            bm, verts=[v for v in bm.verts if v.is_valid],
            factor=0.25,
            use_axis_x=True, use_axis_y=True, use_axis_z=True,
        )

    # Transform back to local space
    bm.transform(obj.matrix_world.inverted())
    bm.to_mesh(mesh)
    mesh.update()
    bm.free()


# ---------------------------------------------------------------------------
#  Edge loop enforcement
# ---------------------------------------------------------------------------

def _enforce_edge_loops_at_sharp(obj, settings):
    """
    After quad conversion, ensure sharp-marked edges actually have
    clean edge loops by dissolving any nearby non-sharp edges that
    break the loop flow.
    """
    mesh = obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    dissolved = 0
    for edge in list(bm.edges):
        if not edge.is_valid or edge.smooth:
            continue
        for vert in edge.verts:
            if not vert.is_valid:
                continue
            linked_tris = [f for f in vert.link_faces if f.is_valid and len(f.verts) == 3]
            if len(linked_tris) < 2:
                continue
            try:
                bmesh.ops.join_triangles(
                    bm, faces=linked_tris,
                    angle_face_threshold=settings.face_angle_limit,
                    angle_shape_threshold=settings.shape_angle_limit,
                    topology_influence=1.0,
                )
                dissolved += 1
            except Exception:
                pass

    if dissolved > 0:
        bm.faces.ensure_lookup_table()
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
        bm.normal_update()
        bm.to_mesh(mesh)
        mesh.validate(verbose=False)
        mesh.update()

    bm.free()
    return dissolved


# ---------------------------------------------------------------------------
#  Main pipeline
# ---------------------------------------------------------------------------

def _run_retopology(obj, settings, report_fn):
    """
    Full retopology pipeline:
      1. Snapshot original for projection
      2. Detect & mark sharp feature edges
      2b. Ridge and curvature detection
      2c. Hole / circle loop detection
      3. Repair non-manifold
      4. Quadriflow reduction (two-stage if target < 5000)
      5. Edge loop enforcement at sharp features
      5b. Adaptive density reduction in flat regions
      6. Beautify & smooth
      7. Project back onto original surface
      8. Clean up temp objects
    """
    mesh = obj.data
    original_faces = len(mesh.polygons)

    wm = bpy.context.window_manager
    wm.progress_begin(0, 100)

    try:
        # --- 1. Snapshot for projection ------------------------------------
        wm.progress_update(5)
        source_obj = None
        if settings.project_to_source or settings.reduce_polycount:
            source_obj = _snapshot_as_object(obj)

        # --- 2. Sharp edge detection ---------------------------------------
        wm.progress_update(8)
        sharp_count = 0
        ridge_count = 0
        curv_count = 0
        hole_count = 0
        if settings.preserve_sharp:
            sharp_count = _detect_and_mark_sharp_edges(obj, settings.sharp_angle)
            report_fn({"INFO"}, f"Marked {sharp_count:,} sharp feature edges")
        if settings.preserve_seams:
            _detect_and_mark_seam_edges(obj)

        # --- 2b. Ridge and curvature detection -----------------------------
        wm.progress_update(12)
        if settings.detect_ridges:
            ridge_count = _detect_and_mark_ridges(obj, settings)
            report_fn({"INFO"}, f"Marked {ridge_count:,} ridge/valley edges")
            curv_count = _mark_principal_curvature_edges(obj, settings)
            report_fn({"INFO"}, f"Marked {curv_count:,} curvature-flow edges")

        # --- 2c. Hole / circle loop detection ------------------------------
        wm.progress_update(16)
        if settings.detect_holes:
            hole_count = _detect_and_mark_hole_loops(obj, settings)
            hole_count += _detect_circular_topology(obj, settings)
            report_fn({"INFO"}, f"Marked {hole_count:,} hole/circle loop edges")

        # --- 3. Non-manifold repair ----------------------------------------
        wm.progress_update(20)
        repair_info = {"merged": 0, "holes_filled": 0, "nm_fixed": 0, "loose_removed": 0}
        if settings.fix_nonmanifold:
            repair_info = _repair_nonmanifold(obj, settings)

        # --- 4. Poly reduction (Quadriflow) ----------------------------------
        wm.progress_update(25)
        source_already_projected = False
        if settings.reduce_polycount:
            final_target = settings.target_faces

            if final_target < 5000:
                # Two-stage: reduce to 5000 first for better projection,
                # then reduce to final target without further projection.
                _reduce_with_quadriflow_target(obj, 5000, settings)
                report_fn({"INFO"}, f"Stage 1: reduced to {len(obj.data.polygons):,} faces for projection")

                if source_obj and settings.project_to_source:
                    _project_to_surface(obj, source_obj, settings)
                    report_fn({"INFO"}, "Projected to source at intermediate resolution")

                if settings.beautify:
                    _beautify_and_smooth(obj, settings)

                _reduce_with_quadriflow_target(obj, final_target, settings)
                report_fn({"INFO"}, f"Stage 2: reduced to {len(obj.data.polygons):,} faces (final)")
                source_already_projected = True
            else:
                _reduce_with_quadriflow(obj, settings)

        after_reduce = len(obj.data.polygons)
        mesh = obj.data  # refresh after Quadriflow may swap mesh data
        wm.progress_update(60)

        # --- 5. Edge loop enforcement at sharp edges -----------------------
        if settings.preserve_sharp:
            _enforce_edge_loops_at_sharp(obj, settings)

        # --- 5b. Adaptive density: reduce flat regions --------------------
        wm.progress_update(70)
        if settings.adaptive_density:
            dissolved, remaining_tris, remaining_ngons = _reduce_flat_regions(
                obj, settings.adaptive_strength)
            report_fn({"INFO"},
                f"Adaptive density: removed {dissolved:,} faces from flat regions "
                f"(remaining T:{remaining_tris:,} N:{remaining_ngons:,})")

        # --- 7. Beautify & smooth ------------------------------------------
        wm.progress_update(85)
        if settings.beautify and not source_already_projected:
            _beautify_and_smooth(obj, settings)

        # --- 8. Project back to source -------------------------------------
        wm.progress_update(90)
        if source_obj and settings.project_to_source and not source_already_projected:
            _project_to_surface(obj, source_obj, settings)

        # --- 9. Cleanup ----------------------------------------------------
        wm.progress_update(95)
        if source_obj:
            _cleanup_temp_object(source_obj)

        # Final stats
        final_faces = len(mesh.polygons)
        bm = bmesh.new()
        bm.from_mesh(mesh)
        final_stats = _count_topology(bm)
        bm.free()

        wm.progress_update(100)

        report_fn({"INFO"},
            f"Done: {original_faces:,} -> {final_faces:,} faces "
            f"({100.0 * final_faces / max(1, original_faces):.1f}%) | "
            f"Q:{final_stats['quads']:,} T:{final_stats['tris']:,} "
            f"N:{final_stats['ngons']:,} | "
            f"Sharp:{sharp_count:,} Ridge:{ridge_count:,} "
            f"Holes:{hole_count:,} Merged:{repair_info['merged']:,}"
        )

    finally:
        wm.progress_end()


# ---------------------------------------------------------------------------
#  Operators
# ---------------------------------------------------------------------------

class MESH_OT_retopologize(Operator):
    bl_idname = "mesh.retopologize"
    bl_label = "Retopologize"
    bl_description = (
        "Full retopology pipeline: reduce polys, preserve sharp features, "
        "convert to clean quad topology, project back to original surface"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        s = context.scene.retopology_settings
        mode = obj.mode
        if mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        try:
            _run_retopology(obj, s, self.report)
        except Exception as ex:
            self.report({"ERROR"}, f"Retopology failed: {ex}")
            return {"CANCELLED"}
        finally:
            bpy.ops.object.mode_set(mode=mode)

        return {"FINISHED"}


class MESH_OT_repair_only(Operator):
    bl_idname = "mesh.retopo_repair_only"
    bl_label = "Repair Non-Manifold Only"
    bl_description = "Only repair non-manifold geometry without changing topology"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        s = context.scene.retopology_settings
        mode = obj.mode
        if mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        info = _repair_nonmanifold(obj, s)
        bpy.ops.object.mode_set(mode=mode)
        self.report({"INFO"},
            f"Merged: {info['merged']}, Holes: {info['holes_filled']}, "
            f"NM fixed: {info['nm_fixed']}, Loose: {info['loose_removed']}")
        return {"FINISHED"}


class MESH_OT_mark_sharp_features(Operator):
    bl_idname = "mesh.retopo_mark_sharp"
    bl_label = "Preview Sharp Edges"
    bl_description = "Mark and highlight edges that will be treated as sharp features"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        s = context.scene.retopology_settings
        mode = obj.mode
        if mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")

        count = _detect_and_mark_sharp_edges(obj, s.sharp_angle)
        if s.preserve_seams:
            count += _detect_and_mark_seam_edges(obj)
        ridge_count = 0
        curv_count = 0
        hole_count = 0
        if s.detect_ridges:
            ridge_count = _detect_and_mark_ridges(obj, s)
            curv_count = _mark_principal_curvature_edges(obj, s)
        if s.detect_holes:
            hole_count = _detect_and_mark_hole_loops(obj, s)
            hole_count += _detect_circular_topology(obj, s)

        # Enter edit mode and select sharp edges for visual preview
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.select_all(action="DESELECT")

        bm = bmesh.from_edit_mesh(obj.data)
        for e in bm.edges:
            e.select = not e.smooth
        bm.select_flush_mode()
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

        # Also enable sharp edge overlay
        for area in bpy.context.screen.areas:
            if area.type == "VIEW_3D":
                for space in area.spaces:
                    if space.type == "VIEW_3D":
                        space.overlay.show_edge_sharp = True

        self.report({"INFO"},
            f"Sharp:{count:,} Ridge:{ridge_count:,} "
            f"Curv:{curv_count:,} Holes:{hole_count:,}")
        return {"FINISHED"}


class MESH_OT_clear_sharp(Operator):
    bl_idname = "mesh.retopo_clear_sharp"
    bl_label = "Clear Sharp Marks"
    bl_description = "Remove all sharp edge marks"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        mode = obj.mode
        if mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        _clear_sharp_marks(obj)
        bpy.ops.object.mode_set(mode=mode)
        self.report({"INFO"}, "Cleared all sharp marks")
        return {"FINISHED"}


class MESH_OT_preview_nonquad(Operator):
    bl_idname = "mesh.retopo_preview_nonquad"
    bl_label = "Preview Non-Quads"
    bl_description = "Select all non-quad faces"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        if obj.mode != "EDIT":
            bpy.ops.object.mode_set(mode="EDIT")
        bpy.context.tool_settings.mesh_select_mode = (False, False, True)
        bm = bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        count = 0
        for f in bm.faces:
            nq = len(f.verts) != 4
            f.select = nq
            if nq:
                count += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        self.report({"INFO"}, f"Selected {count:,} non-quad faces")
        return {"FINISHED"}


class MESH_OT_retopo_stats(Operator):
    bl_idname = "mesh.retopo_stats"
    bl_label = "Mesh Stats"
    bl_description = "Display topology statistics"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == "MESH"

    def execute(self, context):
        obj = context.active_object
        mesh = obj.data
        bm = bmesh.new()
        bm.from_mesh(mesh)
        s = _count_topology(bm)
        sharp = sum(1 for e in bm.edges if not e.smooth)
        boundary = sum(1 for e in bm.edges if e.is_boundary)
        bm.free()
        self.report({"INFO"},
            f"V:{len(mesh.vertices):,} E:{len(mesh.edges):,} F:{len(mesh.polygons):,} | "
            f"Quads:{s['quads']:,} Tris:{s['tris']:,} Ngons:{s['ngons']:,} | "
            f"NM-Edges:{s['nm_edges']} Sharp:{sharp:,} Boundary:{boundary}")
        return {"FINISHED"}


# ---------------------------------------------------------------------------
#  UI Panel
# ---------------------------------------------------------------------------

class VIEW3D_PT_retopology_tool(Panel):
    bl_label = "Retopology Tool"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Retopology"

    def draw(self, context):
        layout = self.layout
        s = context.scene.retopology_settings

        # -- Mesh info --------------------------------------------------------
        obj = context.active_object
        if obj and obj.type == "MESH":
            fc = len(obj.data.polygons)
            box = layout.box()
            row = box.row()
            if fc > 500_000:
                row.label(text=f"Faces: {fc:,}", icon="ERROR")
                row = box.row()
                row.label(text="Very dense — use Quadriflow or Voxel+Quad mode")
            elif fc > 50_000:
                row.label(text=f"Faces: {fc:,}", icon="INFO")
            else:
                row.label(text=f"Faces: {fc:,}", icon="CHECKMARK")

        # -- Analysis ---------------------------------------------------------
        box = layout.box()
        box.label(text="Analysis", icon="VIEWZOOM")
        row = box.row(align=True)
        row.operator(MESH_OT_retopo_stats.bl_idname, icon="INFO")
        row.operator(MESH_OT_preview_nonquad.bl_idname, icon="FACESEL")

        # -- Sharp features ---------------------------------------------------
        box = layout.box()
        box.label(text="Feature Preservation", icon="EDGESEL")
        col = box.column(align=True)
        col.prop(s, "preserve_sharp")
        if s.preserve_sharp:
            col.prop(s, "sharp_angle")
        col.prop(s, "preserve_boundary")
        col.prop(s, "preserve_seams")
        col.separator()
        col.prop(s, "detect_ridges")
        if s.detect_ridges:
            col.prop(s, "ridge_sensitivity")
            col.prop(s, "ridge_smooth_iterations")
        col.separator()
        col.prop(s, "detect_holes")
        if s.detect_holes:
            col.prop(s, "hole_loop_rings")
            col.prop(s, "hole_min_edges")
        row = box.row(align=True)
        row.operator(MESH_OT_mark_sharp_features.bl_idname, icon="RESTRICT_SELECT_OFF")
        row.operator(MESH_OT_clear_sharp.bl_idname, icon="X")

        # -- Poly reduction ---------------------------------------------------
        box = layout.box()
        box.label(text="Poly Reduction", icon="MOD_DECIM")
        box.prop(s, "reduce_polycount")
        if s.reduce_polycount:
            col = box.column(align=True)
            col.prop(s, "target_faces")
            col.label(text="Edges will follow surface curvature", icon="INFO")
            col.prop(s, "use_symmetry")
            if s.use_symmetry:
                col.prop(s, "symmetry_axis")
            # Show reduction percentage
            if obj and obj.type == "MESH":
                fc = len(obj.data.polygons)
                if fc > 0:
                    pct = 100.0 * s.target_faces / fc
                    col.label(text=f"Reduction: {fc:,} -> {s.target_faces:,} ({pct:.1f}%)")

        # -- Non-manifold repair -----------------------------------------------
        box = layout.box()
        box.label(text="Non-Manifold Repair", icon="MOD_MESHDEFORM")
        box.prop(s, "fix_nonmanifold")
        if s.fix_nonmanifold:
            col = box.column(align=True)
            col.prop(s, "merge_distance")
            col.prop(s, "fill_holes")
            if s.fill_holes:
                col.prop(s, "max_hole_edges")
            col.prop(s, "recalc_normals")
            box.operator(MESH_OT_repair_only.bl_idname, icon="MODIFIER")

        # -- Adaptive density ------------------------------------------------
        box = layout.box()
        box.label(text="Adaptive Density", icon="MOD_REMESH")
        box.prop(s, "adaptive_density")
        if s.adaptive_density:
            col = box.column(align=True)
            col.prop(s, "adaptive_strength")

        # -- Beautify ---------------------------------------------------------
        box = layout.box()
        box.label(text="Smooth & Relax", icon="MOD_SMOOTH")
        box.prop(s, "beautify")
        if s.beautify:
            col = box.column(align=True)
            col.prop(s, "beautify_iterations")
            col.prop(s, "beautify_strength")
            col.prop(s, "preserve_volume")
            if s.preserve_volume:
                col.prop(s, "volume_strength")

        # -- Projection -------------------------------------------------------
        box = layout.box()
        box.label(text="Surface Projection", icon="MOD_SHRINKWRAP")
        box.prop(s, "project_to_source")
        if s.project_to_source:
            col = box.column(align=True)
            col.prop(s, "project_iterations")
            col.prop(s, "project_smooth")

        # -- Execute ----------------------------------------------------------
        layout.separator()
        row = layout.row(align=True)
        row.scale_y = 1.8
        row.operator(MESH_OT_retopologize.bl_idname, icon="MESH_GRID")


# ---------------------------------------------------------------------------
#  Registration
# ---------------------------------------------------------------------------

classes = (
    RetopologySettings,
    MESH_OT_retopologize,
    MESH_OT_repair_only,
    MESH_OT_mark_sharp_features,
    MESH_OT_clear_sharp,
    MESH_OT_preview_nonquad,
    MESH_OT_retopo_stats,
    VIEW3D_PT_retopology_tool,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.retopology_settings = PointerProperty(type=RetopologySettings)


def unregister():
    del bpy.types.Scene.retopology_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
